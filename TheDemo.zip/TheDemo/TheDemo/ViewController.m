//
//  ViewController.m
//  TheDemo
//
//  Created by CompuCharm Studios on 28/06/15.
//  Copyright (c) 2015 CompuCharm Studios. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSDictionary *flickrDictionary;
    
    NSMutableArray *cFRAIPArray;
}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self callWebService];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) callWebService
{
    NSURL *myURL = [NSURL URLWithString:@"http://clipme.in/stich/wsRC/?fromClient=Android&func=homepage_video&page=2&token=a3b2214fba198530dd83af8cf1563377&c=home&userId=1525"];
    NSURLRequest *myRequest = [NSURLRequest requestWithURL:myURL];
    NSURLConnection *myConnection = [NSURLConnection connectionWithRequest:myRequest
                                                                  delegate:self];
    
}

#pragma mark - NSURL Delegate

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse*) response;
    
    int errorCode = httpResponse.statusCode;
    
    NSString *fileMIMEType = [[httpResponse MIMEType] lowercaseString];
    
    NSLog(@"response is %d, %@", errorCode, fileMIMEType);
    
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    
    NSLog(@"data is %@", data);
    
    NSString *myString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    NSLog(@"string is %@", myString);
    
    NSError *e = nil;
    
    flickrDictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&e];
    
    NSLog(@"dictionary is %@", flickrDictionary);
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    
    
    
    // inform the user
    
    NSLog(@"Connection failed! Error - %@ %@",
          
          [error localizedDescription],
          
          [[error userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]);
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
    // do something with the data
    
    // receivedData is declared as a method instance elsewhere
    
    cFRAIPArray = [[NSMutableArray alloc] initWithCapacity:5];
    
    for (NSString *key in flickrDictionary)
    {
        
        NSLog(@"the key is %@", flickrDictionary[key]);
        
        id object = flickrDictionary[key]; // this will be apikey,format,method etc...
        
        if ([object isKindOfClass:[NSDictionary class]])
        { //first 4 are arrays-crsh-dicts
            
            NSLog(@"object valueForKey is %@", [object valueForKey:@"_content"]);
            
            [cFRAIPArray addObject:[object valueForKey:@"_content"]];
            
            
            
        } else {
            
            [cFRAIPArray addObject:flickrDictionary[key]];
            
        }
        
    }
    
    NSLog(@"cfraiparray %@", cFRAIPArray);
    
    [self.theTableView reloadData];
    
    NSLog(@"Succeeded!");
    
    
    
}


@end
