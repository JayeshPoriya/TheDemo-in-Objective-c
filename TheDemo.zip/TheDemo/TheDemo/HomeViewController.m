//
//  HomeViewController.m
//  TheDemo
//
//  Created by CompuCharm Studios on 28/06/15.
//  Copyright (c) 2015 CompuCharm Studios. All rights reserved.
//

#import "HomeViewController.h"
#import "HomeTableViewCell.h"
#import "UIImageView+WebCache.h"
#import "FileDownloadInfo.h"
#import "AppDelegate.h"
#import <MediaPlayer/MediaPlayer.h>




// Define some constants regarding the tag values of the prototype cell's subviews.
#define CellLabelTagValue               10
#define CellStartPauseButtonTagValue    20
#define CellStopButtonTagValue          30
#define CellProgressBarTagValue         1
#define CellLabelReadyTagValue          50

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [tblForVideo registerNib:[UINib nibWithNibName:@"HomeTableViewCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"myCell"];
    
    
    
    NSArray *URLs = [[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask];
    self.docDirectoryURL = [URLs objectAtIndex:0];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];

    NSArray *allFiles = [fileManager contentsOfDirectoryAtURL:self.docDirectoryURL
                                   includingPropertiesForKeys:nil
                                                      options:NSDirectoryEnumerationSkipsHiddenFiles
                                                        error:nil];
    for (int i=0; i<[allFiles count]; i++) {
        [fileManager removeItemAtURL:[allFiles objectAtIndex:i] error:nil];
    }

    
    
    
    
    arrayForVideos = [[NSMutableArray alloc]init];
    [self loadData];
    
    
    
    NSURLSessionConfiguration *sessionConfiguration = [NSURLSessionConfiguration backgroundSessionConfigurationWithIdentifier:@"com.compucharm.TheDemo"];
    sessionConfiguration.HTTPMaximumConnectionsPerHost = 5;
    
    
    self.session = [NSURLSession sessionWithConfiguration:sessionConfiguration
                                                 delegate:self
                                            delegateQueue:nil];
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - uitableview delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrayForVideos.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HomeTableViewCell *cell = (HomeTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"myCell"];
    NSLog(@"arrayForVideos is %@", arrayForVideos);
    
    cell.progressView.progress = 0.0f;
    cell.btnDownload.tag = indexPath.row;
    cell.progressView.hidden = YES;
    
    
    
    
    cell.lblVideoName.text = [[[[[arrayForVideos objectAtIndex:indexPath.row] valueForKey:@"participant_details"] valueForKey:@"owner"] objectAtIndex:0] valueForKey:@"participantName"];
    
    [cell.imgForVideo sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[[arrayForVideos objectAtIndex:indexPath.row] valueForKey:@"videoThumb"]]]
                 placeholderImage:[UIImage imageNamed:@"avatar-placeholder.png"]
                          options:SDWebImageRefreshCached];
    
    
    FileDownloadInfo *fdi = [self.arrFileDownloadData objectAtIndex:indexPath.row];

    
    if (fdi.downloadComplete)
    {
        // Hide the progress view and disable the stop button.
        cell.progressView.hidden = YES;
        
        [cell.btnDownload setTitle:@"Play" forState:UIControlStateNormal];
        
    }
    else
    {
        [cell.btnDownload setTitle:@"Download" forState:UIControlStateNormal];

    }
    
    
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

#pragma mark - custome method

-(void)loadData
{
    @try
    {
        
        spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.center = CGPointMake(160, 240);
        spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        [spinner startAnimating];
        
        
        
        NSURL *myURL = [NSURL URLWithString:@"http://clipme.in/stich/wsRC/?fromClient=Android&func=homepage_video&page=2&token=a3b2214fba198530dd83af8cf1563377&c=home&userId=1525"];
        NSURLRequest *myRequest = [NSURLRequest requestWithURL:myURL];
        NSURLConnection *myConnection = [NSURLConnection connectionWithRequest:myRequest delegate:self];
        NSLog(@"myConnection ==> %@",myConnection);
    }
    @catch (NSException *exception)
    {
        NSLog(@"exception ==> %@",exception);
    }
   
}

- (void) startDownloadingVideoWithTag: (int) theTag
{
    
    
    HomeTableViewCell * cell = (HomeTableViewCell *)[tblForVideo cellForRowAtIndexPath:[NSIndexPath indexPathForRow:theTag inSection:0]];
    [cell.progressView setHidden:NO];
    
//    NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@",[[arrayForVideos objectAtIndex:theTag] valueForKey:@"video_url"]]];
//    
//    NSLog(@"URL IS %@",URL);
//    
//    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
//    
////    NSURLSessionConfiguration *sessionConfig = [NSURLSessionConfiguration defaultSessionConfiguration];
//    
//    NSURLSessionConfiguration *sessionConfig = [NSURLSessionConfiguration backgroundSessionConfiguration:@"com.BGTransferDemo"];
////    sessionConfiguration.HTTPMaximumConnectionsPerHost = 5;
//    
//    
//    self.session = [NSURLSession sessionWithConfiguration:sessionConfig
//                                                 delegate:self
//                                            delegateQueue:nil];
    
    
//    self.arrFileDownloadData = [[NSMutableArray alloc] init];
//    [self.arrFileDownloadData addObject:[[FileDownloadInfo alloc] initWithFileTitle:@"iOS Programming Guide" andDownloadSource:[NSString stringWithFormat:@"%@",[[arrayForVideos objectAtIndex:theTag] valueForKey:@"video_url"]]]];
    
    FileDownloadInfo *fdi = [self.arrFileDownloadData objectAtIndex:theTag];
    
    
    NSLog(@"THE ROCK %@",[arrayForVideos[theTag] valueForKey:@"video_url"]);
    
     if (!fdi.isDownloading)
     {
         // Check if should create a new download task using a URL, or using resume data.
         if (fdi.taskIdentifier == -1)
         {
             fdi.downloadTask = [self.session downloadTaskWithURL:[NSURL URLWithString:fdi.downloadSource]];
         }
         else{
             fdi.downloadTask = [self.session downloadTaskWithResumeData:fdi.taskResumeData];
         }
         
         // Keep the new taskIdentifier.
         fdi.taskIdentifier = fdi.downloadTask.taskIdentifier;
         
         // Start the download.
         [fdi.downloadTask resume];
         
         // Indicate for each file that is being downloaded.
         fdi.isDownloading = YES;
     }


//    //session.delegate = self;
//    NSURLSessionDownloadTask *downloadTask = [self.session downloadTaskWithURL:URL
//                                                            completionHandler:
//                                              ^(NSURL *location, NSURLResponse *response, NSError *error)
//                                              {
//                                                  NSLog(@"REs is %@",response);
//                                                  NSLog(@"ERR is %@",[error localizedDescription]);
//                                                  
//                                                  NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
//                                                  NSURL *documentsDirectoryURL = [NSURL fileURLWithPath:documentsPath];
//                                                  NSURL *documentURL = [documentsDirectoryURL URLByAppendingPathComponent:[response
//                                                                                                                           suggestedFilename]];
//                                                  [[NSFileManager defaultManager] moveItemAtURL:location
//                                                                                          toURL:documentURL
//                                                                                          error:nil];
//                                                  
//                                                  NSLog(@"DOC URL IS %@",documentURL);
//                                              }];
//    
//    
//    [downloadTask resume];
}

-(void)playVideoWithTag:(int)theTag
{
    
    NSURL *vedioURL = destinationURL;
    
    
//    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    NSLog(@"files paths %@", paths);
//    
//    NSString *documentsDirectory = [paths objectAtIndex:0];
//    
//    NSLog(@"files documentsDirectory %@", documentsDirectory);
//    
//    
//    NSArray *filePathsArray = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:documentsDirectory  error:nil];
//    NSLog(@"files array %@", filePathsArray);
//    
//    NSString *fullpath;
//    
//    for ( NSString *apath in filePathsArray )
//    {
//        fullpath = [documentsDirectory stringByAppendingPathComponent:apath];
//        vedioURL =[NSURL fileURLWithPath:fullpath];
//    }
    NSLog(@"vurl %@",vedioURL);
    MPMoviePlayerViewController *videoPlayerView = [[MPMoviePlayerViewController alloc] initWithContentURL:vedioURL];
    //[self presentMoviePlayerViewControllerAnimated:videoPlayerView];
    [videoPlayerView.moviePlayer play];

}


#pragma mark - NSURLSession Delegate method implementation

-(void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didFinishDownloadingToURL:(NSURL *)location
{
    
    NSError *error;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSString *destinationFilename = downloadTask.originalRequest.URL.lastPathComponent;
    destinationURL = [self.docDirectoryURL URLByAppendingPathComponent:destinationFilename];
    
    if ([fileManager fileExistsAtPath:[destinationURL path]]) {
        [fileManager removeItemAtURL:destinationURL error:nil];
    }
    
    BOOL success = [fileManager copyItemAtURL:location
                                        toURL:destinationURL
                                        error:&error];
    
    if (success) {
        // Change the flag values of the respective FileDownloadInfo object.
        int index = [self getFileDownloadInfoIndexWithTaskIdentifier:downloadTask.taskIdentifier];
        FileDownloadInfo *fdi = [self.arrFileDownloadData objectAtIndex:index];
        
        fdi.isDownloading = NO;
        fdi.downloadComplete = YES;
        
        // Set the initial value to the taskIdentifier property of the fdi object,
        // so when the start button gets tapped again to start over the file download.
        fdi.taskIdentifier = -1;
        
        // In case there is any resume data stored in the fdi object, just make it nil.
        fdi.taskResumeData = nil;
        
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            // Reload the respective table view row using the main thread.
            [tblForVideo reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:index inSection:0]]
                                 withRowAnimation:UITableViewRowAnimationNone];
            
        }];
        
        MPMoviePlayerViewController *videoPlayerView = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL fileURLWithPath:destinationURL.path]];
        //[self presentMoviePlayerViewControllerAnimated:videoPlayerView];
        [videoPlayerView.moviePlayer play];
        
    }
    else{
        NSLog(@"Unable to copy temp file. Error: %@", [error localizedDescription]);
    }

}


-(void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error{
    if (error != nil) {
        NSLog(@"Download completed with error: %@", [error localizedDescription]);
    }
    else{
        NSLog(@"Download finished successfully.");
        
           int index = [self getFileDownloadInfoIndexWithTaskIdentifier:task.taskIdentifier];
        
        NSIndexPath *cellIndexPath = [NSIndexPath indexPathForRow:index inSection:0];
        
         //HomeTableViewCell *cell =(HomeTableViewCell *)[tblForVideo cellForRowAtIndexPath:cellIndexPath];
        //[cell.btnDownload setTitle:@"Play" forState:UIControlStateNormal];
        
        // = [tblForVideo indexPathForCell:cell];

        //int cellIndex = cellIndexPath.row;
        FileDownloadInfo *fdi = [self.arrFileDownloadData objectAtIndex:cellIndexPath.row];
        fdi.isDownloading = !fdi.isDownloading;
        
        fdi.downloadComplete = YES;


        dispatch_async(dispatch_get_main_queue(), ^{
            [tblForVideo reloadRowsAtIndexPaths:@[cellIndexPath] withRowAnimation:UITableViewRowAnimationNone];
        }) ;
        
        
        NSError *error;
        NSFileManager *fileManager = [NSFileManager defaultManager];
        
        NSString *destinationFilename = task.originalRequest.URL.lastPathComponent;
        NSURL *destinationURL = [self.docDirectoryURL URLByAppendingPathComponent:destinationFilename];
        
        if ([fileManager fileExistsAtPath:[destinationURL path]]) {
            [fileManager removeItemAtURL:destinationURL error:nil];
        }
    }
}


-(void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didWriteData:(int64_t)bytesWritten totalBytesWritten:(int64_t)totalBytesWritten totalBytesExpectedToWrite:(int64_t)totalBytesExpectedToWrite
{
    NSLog(@"DownloadTask");
    
    if (totalBytesExpectedToWrite == NSURLSessionTransferSizeUnknown) {
        NSLog(@"Unknown transfer size");
    }
    else{
        // Locate the FileDownloadInfo object among all based on the taskIdentifier property of the task.
        int index = [self getFileDownloadInfoIndexWithTaskIdentifier:downloadTask.taskIdentifier];
        FileDownloadInfo *fdi = [self.arrFileDownloadData objectAtIndex:index];
        
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
            // Calculate the progress.
            fdi.downloadProgress = (double)totalBytesWritten / (double)totalBytesExpectedToWrite;
            
            // Get the progress view of the appropriate cell and update its progress.
            HomeTableViewCell *cell =(HomeTableViewCell *)[tblForVideo cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
            cell.progressView = (UIProgressView *)[cell viewWithTag:CellProgressBarTagValue];
            cell.progressView.progress = fdi.downloadProgress;
            
            NSLog(@"downloadProgress => %f",fdi.downloadProgress);
            
            
            
        }];
    }
}

-(int)getFileDownloadInfoIndexWithTaskIdentifier:(unsigned long)taskIdentifier{
    int index = 0;
    for (int i=0; i<[self.arrFileDownloadData count]; i++) {
        FileDownloadInfo *fdi = [self.arrFileDownloadData objectAtIndex:i];
        if (fdi.taskIdentifier == taskIdentifier) {
            index = i;
            break;
        }
    }
    
    return index;
}


-(void)URLSessionDidFinishEventsForBackgroundURLSession:(NSURLSession *)session{
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    
    // Check if all download tasks have been finished.
    [self.session getTasksWithCompletionHandler:^(NSArray *dataTasks, NSArray *uploadTasks, NSArray *downloadTasks) {
        
        if ([downloadTasks count] == 0) {
            if (appDelegate.backgroundTransferCompletionHandler != nil) {
                // Copy locally the completion handler.
                void(^completionHandler)() = appDelegate.backgroundTransferCompletionHandler;
                
                // Make nil the backgroundTransferCompletionHandler.
                appDelegate.backgroundTransferCompletionHandler = nil;
                
                [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                    // Call the completion handler to tell the system that there are no other background transfers.
                    completionHandler();
                    
                    // Show a local notification when all downloads are over.
                    UILocalNotification *localNotification = [[UILocalNotification alloc] init];
                    localNotification.alertBody = @"All files have been downloaded!";
                    [[UIApplication sharedApplication] presentLocalNotificationNow:localNotification];
                }];
            }
        }
    }];
}






#pragma mark - url connetion delegate


- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse*) response;
    int errorCode = httpResponse.statusCode;
    NSString *fileMIMEType = [[httpResponse MIMEType] lowercaseString];
    NSLog(@"response is %d, %@", errorCode, fileMIMEType);
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    NSLog(@"data is %@", data);
    
    NSString *myString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"string is %@", myString);
    
    NSError *e = nil;
    
    arrayForVideos = [[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&e] valueForKey:@"LIST"];
    NSLog(@"arrayForVideos is %@", arrayForVideos);
    
    for (int i = 0; i<arrayForVideos.count; i++)
    {
        if (self.arrFileDownloadData.count == 0) {
            self.arrFileDownloadData = [[NSMutableArray alloc]init];
        }
        
        NSString *VURL = [[arrayForVideos objectAtIndex:i] valueForKey:@"video_url"];
        NSString *NAME = [[arrayForVideos objectAtIndex:i] valueForKey:@"userName"];
        
    
        
        [self.arrFileDownloadData addObject:[[FileDownloadInfo alloc] initWithFileTitle:NAME andDownloadSource:VURL]];
        
        
//        [self.arrFileDownloadData addObject:[[arrayForVideos objectAtIndex:i] valueForKey:@"video_url"]];
    }
    
    
    NSLog(@"self.arrFileDownloadData is %@", self.arrFileDownloadData);

    
    [spinner stopAnimating];
    [tblForVideo reloadData];



}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    // inform the user
    
    NSLog(@"Connection failed! Error - %@ %@",
    [error localizedDescription],
    [[error userInfo] objectForKey:NSURLErrorFailingURLStringErrorKey]);
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    // do something with the data
    // receivedData is declared as a method instance elsewhere
    NSLog(@"Succeeded!");

}



@end
