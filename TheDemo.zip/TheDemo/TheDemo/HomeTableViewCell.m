//
//  HomeTableViewCell.m
//  TheDemo
//
//  Created by CompuCharm Studios on 28/06/15.
//  Copyright (c) 2015 CompuCharm Studios. All rights reserved.
//

#import "HomeTableViewCell.h"
#import "HomeViewController.h"
#import <MediaPlayer/MediaPlayer.h>


@implementation HomeTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)btnDownloadAction:(id)sender
{
    NSLog(@"view ==> %@",self.superview.superview.superview);
    
    if ([self.superview.superview.superview.nextResponder isKindOfClass:[HomeViewController class]])
    {
        UIButton *button = (UIButton *)sender;
        NSLog(@"%d", [button tag]);
        
        NSLog(@"title==>%@",button.titleLabel.text);
        
        if ([button.titleLabel.text isEqualToString:@"Download"]) {
            [(HomeViewController *)self.superview.superview.superview.nextResponder startDownloadingVideoWithTag:[button tag]];

        }
        else
        {
            [(HomeViewController *)self.superview.superview.superview.nextResponder playVideoWithTag:[button tag]];

        }
        
        
        
    }
}
@end
