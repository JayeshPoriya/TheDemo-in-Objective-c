//
//  HomeTableViewCell.h
//  TheDemo
//
//  Created by CompuCharm Studios on 28/06/15.
//  Copyright (c) 2015 CompuCharm Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgForVideo;

@property (weak, nonatomic) IBOutlet UILabel *lblVideoName;

@property (weak, nonatomic) IBOutlet UIProgressView *progressView;
@property (weak, nonatomic) IBOutlet UIButton *btnDownload;



- (IBAction)btnDownloadAction:(id)sender;

@end
