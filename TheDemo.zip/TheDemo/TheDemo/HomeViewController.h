//
//  HomeViewController.h
//  TheDemo
//
//  Created by CompuCharm Studios on 28/06/15.
//  Copyright (c) 2015 CompuCharm Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,NSURLSessionDelegate>
{
    __weak IBOutlet UITableView *tblForVideo;
    NSMutableArray * arrayForVideos;
    UIActivityIndicatorView *spinner;
    NSURL *destinationURL;
    
}
@property (nonatomic, strong) NSURLSession *session;
@property (nonatomic, strong) NSMutableArray *arrFileDownloadData;
@property (nonatomic, strong) NSURL *docDirectoryURL;




- (void) startDownloadingVideoWithTag: (int) theTag;
-(void)playVideoWithTag:(int)theTag;

@end
